export const environment = {
  production: true,
  mapBoxToken: 'pk.eyJ1IjoiZGllZ2hveDkwIiwiYSI6ImNrczd3bHJuYzBlNjQyb3FxMXFlYWVjcHcifQ.zDjnYkKPT0q_yUXo5JZzyg',
  baseUrl: 'http://www.elegantsport.info:8080',
  baseUrlImg: 'http://www.elegantsport.info:8080/api/uploads/img/',
  AUTH_ENDPOINT: 'http://www.elegantsport.info:8080/oauth/token'


};
