export class Rol {
  id:number;
	nombre:string;
	etiqueta:string;

}
