export class MaterialUnidad {

  id: number;
  nombre: string;
  descripcion: string;
}
