export class ProductoTipo {
  id: number;
  nombre: string;
  descripcion: string;
  
}
