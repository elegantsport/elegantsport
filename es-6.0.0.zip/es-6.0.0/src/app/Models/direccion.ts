export class Direccion {

  id: number;
  provincia: string;
  ciudad: string;
  direccion: string
  latitud: number;
  longitud: number;
}
