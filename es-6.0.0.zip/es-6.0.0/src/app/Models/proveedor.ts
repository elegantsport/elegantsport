import { Direccion } from "./direccion";

export class Proveedor {

  id: number;
  nombre_empresa: string;
  representante: string;
  cedula_ruc: string;
  correo: string;
  celular: string;
  telefono_fijo: string;
  direccion: Direccion;

}
