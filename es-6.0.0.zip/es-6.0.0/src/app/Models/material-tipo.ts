export class MaterialTipo {

  id: number;
  nombre: string;
  descripcion: string;
}
